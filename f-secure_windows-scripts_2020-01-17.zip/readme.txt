---
---
# Windows Script Instructions

The Windows configuration gatherer script (`windows.bat` file), is the script to run on the host that is being reviewed. It will collect the necessary information about the host.

- Place the `windows.bat` script in an empty folder on the host marked for review.
- Extract the `accesschk.exe` from the `accesschk.zip` and place exe in the same folder as the `windows.bat`.
- Run the script by right clicking on the file and clicking "Run as administrator".
- The script will display its current task, and display "Completed" when its done.
- Once the script has completed, it will have gathered information about the host, and store it in a folder titled `OUTPUT`.
- Send the results in `OUTPUT` to the respective consultant for review.

The `OUTPUT` folder should be marked as sensitive, and as such should not be communicated in plain text or over email.
