# What Does The Script Do?

The windows.bat script aims to assess a Windows host to ensure that there are no privilege escalation vectors, as well as ensure that the host is sufficiently "hardened" and inline with security best practices.

The write-ups below give a brief introduction into some of the features that Windows has to offer, as well as the security implications of incorrectly configuring them. It also provides a description on how to perform a security review of these features.

This is still a work in progress :( 

## Gathering System Information

In order to assess a host, information about the host needs to first be collected. The first thing that I usually do when assessing a Windows host is grab its System Information. This can be done by typing the following command into` cmd.exe`.

```
systeminfo
```

This command will provide you with information about the host’s operating system and hardware. It will also provide you with any patches that have been applied.

This information could be a quick and easy way to elevate our privileges on the host. Microsoft releases patches to fix security issues, and a non-patched host is likely to have publicly available exploits. While you could google all patch releases and try and map them to the host, there is an easier way.

The information provided by the `systeminfo` command could be fed to a tool created called Windows Exploit Suggestor (https://github.com/GDSSecurity/Windows-Exploit-Suggester). This tool is awesome, as it provides you with the patches that are missing. It will also provide links to the exploits that can be used to exploit the vulnerabilities that the missing patch was created to prevent.

The `finder.py` script makes use of the tool mentioned above.

## Services

Services are basically tasks that are run that require little to know user interaction. A service can be any Windows application that is implemented using Windows Services API. In general, services are created to start when the host boots up, and run under the context of a high privileged user.

If a low privileged user was able to modify the service or the executable that is run by the service, they could run code under the context of the user that the service runs its task.

The script grabs information about the services, such as the task to be be run (`binpath`), and the user that the executable will run under the context of. 

The script also grabs the Security Descriptor Definition Language (SDDL) of each service. The SDDL defines the permissions of the service (Who can modify the binpath, user context, etc).

The script also grabs the file permissions of the executable referenced by the binpath.

TODO: The script should extract the folder permissions of the folder that contains the executable.



### A little more on services from an attackers perspective :)

Services are (in my opinion) the easiest way to execute code under the context of the `SYSTEM` user, provided that you have sufficient privileges to create services. 

Meterpreter and Cobalt Strike both use this as their first technique. Here is an interesting write-up on the techniques that could be used to run code under the `SYSTEM` users context. 

https://blog.cobaltstrike.com/2014/04/02/what-happens-when-i-type-getsystem/

## Scheduled Tasks


Scheduled tasks allow for the periodically or single execution of a task. This is actually quite useful, you could use it to do almost anything (perhaps daily cleanups of your Downloads folder?). It can also be quite dangerous, as tasks are executed with the permissions given to the Scheduled Task when it was created. A badly configured Scheduled Task could allow an attacker to abuse the task to run code as a privileged user.

When a scheduled task is created, the user under which context the task will run, must be specified. Running `schtasks.exe /query /TN <task>` on a task will display this information. An extract of an example is given below.

```
Run As User: SYSTEM
```

While gathering a list of scheduled tasks will display the tasks that are running/will run, it is important to gather the file and folder permissions of the scripts/executables that are executed by the scheduled task.

If a user other that the `Run As User` can modify or abuse the script/executable, they may be able to execute code as the user specified in the `Run As User` parameter.


## Startup Tasks

Windows allows users to specify executables or scripts that should be executed when the operating system boots up. There are a number of ways in which a user can do this. Below are the ones that the host config script takes a looks at.

* Services
* Scheduled Tasks
* Startup Folders
* Registry Entries

While we have covered services and scheduled tasks, it is important to look at tasks in the startup folder as well as any registry entries.

### Startup Folders

Every user that has logged into the host has their own startup folder, where executables/scripts will be executed under the context of that user when the host is booted up, and the user logs in. Executables/scripts in the `Windows` startup folder will always be executed when the host is booted up as the `SYSTEM` user.

The `windows.bat` script retrieves the folder permissions, as well as the file permissions of all files within the Windows startup folder, as well as the startup folder of the current logged in user.

TODO: The script should obtain the file/folder permissions for all startup folders and contents, as well as retrieve any scripts within these folders.

### Registry Entries

The script pulls `Windows Registry` entries that start executables/scripts when the host boots up.It also checks the file permissions of the executables/scripts.

TODO: The script should obtain the folder permissions of the folder containing the startup executable/script

## Outdated Software

Outdated software could allow an attacker to compromise the host or escalate there privileges. I wont go into the details, its been done to death, but the TL;DR keep software up to date. 

The script doesn't do much here, it merely collects a list of installed software and version numbers, the rest is up to you.

## Host-Based Firewalls

Host-based firewalls can be setup to deny traffic to or from a host. This allows the user to block access to services, such as SMB. Firewalls should be configured based on purpose of the host. For instance a web server would allow incoming traffic to port 80/443, while a domain workstation probably shouldn't.

The script grabs the current state of the windows firewall, as well as the defined rules. Just because firewall software is running, doesn't mean that its effective. It could be running, but have rules that allow all inbound and all outbound traffic.

Assessing this requires some context, and the appropriate rules should be in place based on the purpose of the host.

## AlwaysInstallElevated

Microsoft Windows allows administrators to configure registry entries that allow users to install MSI packages under the context of the `SYSTEM` user. This might allow users to install driver and other software without requiring the help of an administrator user. The danger is that this user may run any arbitrary code packaged as an MSI. 

To quote Microsoft.

"This option is equivalent to granting full administrative rights, which can pose a massive security risk. Microsoft strongly discourages the use of this setting." - https://docs.microsoft.com/en-us/windows/desktop/msi/alwaysinstallelevated

If you would like to play around with this yourself, here is a good starting point.

https://pentestlab.blog/2017/02/28/always-install-elevated/

# Interesting Files

Software may store credentials on disk (This has been found to be the case with a lot of software). 

The script looks for some of the more common credential files, such as:

* web.config
* Unattended.xml
* sysprep.xml/inf
* McAfee credential files - Chris wrote a blog post on this :) - https://sawiki.mwri.loc/index.php?title=Decrypt_Stored_Passwords_in_McAfee_Agents

# Users Groups and Their Permissions

# Network Connectivity

## IPv6 Enabled

## Listening Services

## Connection Interfaces

# Environment Path Permissions

# Audit Policy

# CIS Benchmark








