apt-get update
apt-get install git python2 
git clone https://github.com/GDSSecurity/Windows-Exploit-Suggester.git
python Windows-Exploit-Suggester/windows-exploit-suggester.py -u
pip install -r requirements.txt

