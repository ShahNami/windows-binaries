

import os
import sys
import subprocess
import re
from colorama import Fore, Back, Style

if len(sys.argv) < 2:
    print "An Error Occured"
    sys.exit()

dir_path = os.path.dirname(os.path.realpath(__file__))

path = sys.argv[1]+"/OUTPUT"

if not os.path.isdir(path):
    print "No OUTPUT folder found"
    sys.exit()

def runProcess(cmd):    
    return os.popen(cmd).read()

def sysinfo():
    try:
        print
        print "Checking System Information"
        print "-------------------------------------------"
        print
        runProcess('rm "'+dir_path+'"/Windows-Exploit-Suggester/*.xls 2>&1 >/dev/null')
        runProcess('cd "'+dir_path+'"/Windows-Exploit-Suggester && python2 windows-exploit-suggester.py -u')
        sysinfo = runProcess('python2 "'+dir_path+'"/Windows-Exploit-Suggester/windows-exploit-suggester.py -i "' + path+'/sysinfo.txt" -d "'+dir_path+'"/Windows-Exploit-Suggester/*.xls')
        if sysinfo.count("[E]") + sysinfo.count("[M]") >= 1:
            print Fore.RED + "Vulnerability: Missing Security Patches - The following vulnerabilities are present:" + Style.RESET_ALL
            print 
            sysinfo = sysinfo.split('\n')
            for line in sysinfo:
                if (line.count("[E]") == 1 or line.count("[M]") == 1) and line.count("[+]") != 1:
                    print "    * " + str(line).replace("[M]","").replace("[E]","")
        print
    except:
        print "ERROR: System info didnt work"
    
def schtasks():    
    try:
        print
        print "Checking Scheduled Tasks"
        print "-------------------------------------------"
        print
        f = open(path+"/SCHTASKS/All_permissions.txt", "r") 
        permissions = f.read().split("\n\n")
        f.close()
        f = open(path+"/SCHTASKS/schtasks.txt", "r") 
        tasks = f.read().split("\n\n")
        f.close()
        out = ""
        found = False
        for x in permissions:
            first = ""
            for a in x.split("\n"):
                if first == "" and "START" not in a:
                    first = a                    
                b=re.findall('\(.*?\)',a)
                if ("Users:" in a or "Everyone:" in a or "Guest:" in a) and ("F" in str(b) or "W" in str(b) or "M" in str(b)):
                    if found == False:
                        found = True
                        out = Fore.RED + "Vulnerability: Insecure File Permissions (Scheduled tasks privesc) \n\n" +Style.RESET_ALL
                    out+= "    * " + first.split("  ")[0] + "  " + a.replace("  ","") + "\n"
                    #print out     
                #print single
        print out
        print
    except Exception as e:
        print "ERROR: Scheduled tasks didnt work " + str(e)
        
        
        
        
def services():    
    try:
        print "Checking Services"
        print "-------------------------------------------"
        print
        f = open(path+"/SERVICES/binaries.txt", "r") 
        permissions = f.read().split("\n\n")
        f.close()
        out = ""
        found = False
        for x in permissions:
            first = ""
            for a in x.split("\n"):
                if first == "" and "START" not in a:
                    first = a                    
                b=re.findall('\(.*?\)',a)
                if ("Users:" in a or "Everyone:" in a or "Guest:" in a) and ("F" in str(b) or "W" in str(b) or "M" in str(b)):
                    if found == False:
                        found = True
                        out = Fore.RED + "Vulnerability: Insecure File Permissions (Services privesc) \n\n" +Style.RESET_ALL
                    out+= "    * " + first.split("  ")[0] + "  " + a.replace("  ","") + "\n"
                    #print out     
                #print single
        print out
        f = open(path+"/SERVICES/permissions.txt", "r") 
        permissions = f.read().split("\n\n")
        f.close()
        found = False
        out =""
        for x in permissions:
            a = x.split("\n")
            perms = a[0].replace(":",")(").split(")(")
            for p in perms:
                if ("A;" in p) and (";BA" not in p and ";DA" not in p and ";EA" not in p and ";LA" not in p and ";LS" not in p and ";SY" not in p and ";NS" not in p and ";SO" not in p and ";SU" not in p) and ( "GA" in p or "GW" in p):
                    if found == False:
                            found = True
                            out = Fore.RED + "Vulnerability: Insecure Service Permissions (Specfied user can control service) \n\n" +Style.RESET_ALL
                    
                    front = ""
                    back = ""
                    if not p[0] == "(":
                        front = "("
                    if not p[-1] == ")":
                        back = ")"  
                    out+= "    * "  + a[1] +  "  " + front + p + back + "\n"
        print out
    except Exception as e:
        print "ERROR: Serices didnt work " + str(e)
    try:  
        f = open(path+"/SERVICES/services.txt", "r") 
        permissions = f.read().split("\n")
        f.close()
        found = False
        out =""
        for l in permissions: 
            line = l.replace("   ", ",")
            line = re.sub(r'(\W)(?=\1)', "", line).split(",")
            #print line
            if len(line) > 2:
                testing = line[2]
                if "-" in line[2]:
                    testing = line[2].split("-")
                if "/" in line[2]:
                    testing = line[2].split("/")
                testing = str(testing[0])
                if testing.startswith(" "):
                    testing = testing[1:]
                if testing.endswith(" "):
                    testing = testing[:-1]
                if " " in testing and '"' not in testing:
                    if found == False:
                            found = True
                            out = Fore.RED + "Vulnerability: Unquoted Service Path \n\n" +Style.RESET_ALL
                    out+= "    * "  + line[1] +  "  " + testing + "\n"
        print out
        print
    except Exception as e:
        print "ERROR: Serices didnt work " + str(e)
        
    
def interesting():
    print "Checking Interesting Files"
    print "-------------------------------------------"
    print
    try:
        f = open(path+"/INTERESTING_FILES/unattended_install.txt", "r") 
        curr_file = f.read().lower()
        f.close()
        found = False
        if curr_file.count("unattended.") > 0:
            if not found:
                found = True
                print Fore.YELLOW + "Please Review: 'interesting_files.txt' The following files were found:  \n" +Style.RESET_ALL
                print "    * "  + str(curr_file.count("unattended.")) +  " Unattended Install file(s) found " + "\n"
                
        f = open(path+"/INTERESTING_FILES/sysprep.txt", "r") 
        curr_file = f.read().lower()
        f.close()
        if curr_file.count("sysprep.") > 0:
            if not found:
                found = True
                print Fore.YELLOW + "Please Review: 'interesting_files.txt' The following files were found:  \n" +Style.RESET_ALL
            print "    * "  + str(curr_file.count("sysprep.")) +  " Sysprep file(s) found " + "\n"
                
                
                
        f = open(path+"/INTERESTING_FILES/webconf.txt", "r") 
        curr_file = f.read().lower()
        f.close()
        if curr_file.count("web.config") > 0:
            if not found:
                found = True
                print Fore.YELLOW + "Please Review: 'interesting_files.txt' The following files were found:  \n" +Style.RESET_ALL
            print "    * "  + str(curr_file.count("web.config")) +  " Web.config file(s) found " + "\n"
                
                
                
    except Exception as e:
        print "An Error Occured [Interesting Files] " + str(e)     
        
  
def account():
    print "Checking Account Details"
    print "-------------------------------------------"
    print
    try:
        f = open(path+"/USERS/account.txt", "r") 
        info = f.read().split("\n")
        f.close()
        args = {}
        for l in info:
            line = l.replace("   ", ",")
            line = re.sub(r'(\W)(?=\1)', "", line).split(",")
            if len(line) > 1:
                args[line[0].replace(" ","")] = line[1].replace(" ","")
        if int(args['Minimumpasswordlength:']) < 12:
            print Fore.RED + "Vulnerability: Weak Password Policy \n" +Style.RESET_ALL
            print "    * Minimum password length is: " + args['Minimumpasswordlength:'] + "\n"
        if args['Lockoutthreshold:'] == "Never":
            print Fore.RED + "Vulnerability: No Account Lockout \n" +Style.RESET_ALL
            print "    * Account lockout set to: " + args['Lockoutthreshold:'] + "\n"
    except Exception as e:
        print "An Error Occured [Account] " + str(e)      


def startupFolder():    
    try:
        print
        print "Checking Startup Folder"
        print "-------------------------------------------"
        print
        f = open(path+"/STARTUP/StartupFolder.txt", "r") 
        folder = f.read().split("\n\n")
        f.close()
        f = open(path+"/STARTUP/StartupFolderPerms.txt", "r") 
        files = f.read().split("\n\n")
        f.close()
        out = ""
        found = False
        for x in files:
            first = ""
            for a in x.split("\n"):
                if first == "" and "START" not in a and "Successfully processed 1 files; Failed processing 0 files" not in a:
                    first = a                 
                b=re.findall('\(.*?\)',a)
                if ("Users:" in a or "Everyone:" in a or "Guest:" in a) and ("F" in str(b) or "W" in str(b) or "M" in str(b)):
                    if found == False:
                        found = True
                        out = Fore.RED + "Vulnerability: Insecure File Permissions (Startup file privesc) \n\n" +Style.RESET_ALL
                    out+= "    * " + first.split("  ")[0] + "  " + a.replace("  ","") + "\n"
                    #print out     
                #print single
        print out
        print
        x = folder[0]
        first = ""
        for a in x.split("\n"):
            out = ""
            b=re.findall('\(.*?\)',a)
            if first == "" and "START" not in a and "Successfully processed 1 files; Failed processing 0 files" not in a:
                    first = a  
            if ("Users:" in a or "Everyone:" in a or "Guest:" in a) and ("F" in str(b) or "W" in str(b) or "M" in str(b)):
                out = Fore.RED + "Vulnerability: Insecure File Permissions (Startup folder privesc) \n\n" +Style.RESET_ALL
                out+= "    * " + first.split("  ")[0] + "  " + a.replace("  ","") + "\n"
                print out
                print
    except Exception as e:
        print "ERROR: Scheduled tasks didnt work " + str(e)


  
  
sysinfo()
schtasks()  
services() 
account()
interesting() 
startupFolder()


























