## Windows Host Configuration Review

This project aims to find vulnerabilities and issues on a Windows host.

The project is split into two parts.

- Windows configuration gatherer script (bat file): This script is run on the host that is being reviewed. It will collect the necessary information about the host.
- Windows configuration processing script (python): This script will use the data collected by the previous script and use it to find vulnerabilities/issues.

These scripts will by no means conduct a full host configuration review. There are many many things that I would like to add (I shall do this quietly and add the changes to this project). Please feel free to branch this project and add something cool. 

Also, I'm not really a fan of using a script for a host config. Please always ask for access to the host when scoping :)

If you want to read more about what the script does, open the "Learning Content" folder.

### Installation

The Windows configuration processing script requires installation. Run the setup.sh file using the following commands.

```bash
chmod +x setup.sh
./setup.sh
```

### Usage

There are two parts to this.

####  Gatherer Script

Place this script on the host that you would like to review. I would place it in a empty folder, it just makes things cleaner. Run the script by right clicking on the file and clicking "Run as administrator". 

The script will display its current task, and display "Completed" when its done. Once the script has completed, it will have gathered information about the host, and store it in a folder titled "OUTPUT".

####  Processing Script

Place the output folder on the host that the "Processing Script" was installed on. Open a terminal and navigate to the directory where the OUTPUT folder is. Run the following command:

```bash
python2 finder.py <path to output folder>
```

If the OUTPUT folder is in the same directory as finder script then use:

```bash
python2 finder.py "$(pwd)"
```

### Completeness

The project is not complete. This table represents how far along the project is. 


| Task                                            | Windows.bat       | finder.py   |
| ------------------------------------------------|:-----------------:| ----------: |
| Missing Security Patches                        |DONE               |DONE         |
| Executable/Script permissions schtasks          |DONE               |DONE         | 
| Executable/Script permissions services          |DONE               |DONE         |
| User permissions on services				      |DONE 		      |DONE         |
| Unquoted service paths					      |DONE 			  |DONE         |
| Interesting Files						          |DONE 		      |DONE         |
| Accounts (Lockout and such)				      |DONE 			  |SEMI         |
| Startup folder permissions of objects and folder|DONE 	          |DONE         |
| Registry startup executable permissions		  |DONE 	          |NOT DONE     |
| Always Elevated								  |DONE  	          |NOT DONE     |
| Passwords in registry							  |DONE 	          |NOT DONE     |
| Environment path permissions (DLL Hijack)		  |DONE 		      |NOT DONE     |
| Auditing										  |DONE 	          |NOT DONE     |
| CIS Benchmark (Includes some vulns)             |DONE               |NOT DONE     |
| Firewall Rules                                  |DONE               |NOT DONE     |
| IPv6 Settings                                   |DONE               |NOT DONE     |


Ultimately the end goal of the project is for you to run a script that detects vulns/issues and then writes the report for you.  

Also I have not fully tested this script on all Windows versions.

